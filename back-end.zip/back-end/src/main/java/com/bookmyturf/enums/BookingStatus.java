package com.bookmyturf.enums;


	public enum BookingStatus { 
		Confirmed, Cancelled, Completed 
		}



