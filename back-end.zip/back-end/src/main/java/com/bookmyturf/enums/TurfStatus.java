package com.bookmyturf.enums;

	public enum TurfStatus {
	    Active,
	    Inactive
	}



