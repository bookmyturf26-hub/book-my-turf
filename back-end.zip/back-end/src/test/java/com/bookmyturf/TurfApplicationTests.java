package com.bookmyturf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurfApplicationTests {

	@Test
	void contextLoads() {
	}

}
